package com.example.echo1

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.RelativeLayout
import android.widget.TextView

class NavigationDrawerAdapter(_contentList:ArrayList<String>,_getImages:IntArray,_content:Context) :RecyclerView.Adapter<NavigationDrawerAdapter.NavViewHolder>(){


    var contextList:ArrayList<String>?=null
    var getImages:IntArray?=null
    var mcontent:Context?=null
    init {
        this.contextList=_contentList
        this.getImages=_getImages
        this.mcontent=_content
    }
    override fun onCreateViewHolder(p0: ViewGroup, p1: Int): NavViewHolder {

        val itemView= LayoutInflater.from(p0.context)
            .inflate(R.layout.row_custom_navigationdrawer,p0,false)
        return NavViewHolder(itemView)
    }

    override fun getItemCount(): Int {
        return (contextList as ArrayList).size

    }

    override fun onBindViewHolder(p0: NavViewHolder, p1: Int) {


        p0.icon_Get?.setBackgroundResource(getImages?.get(p1)as Int)
        p0.text_Get?.text = contextList?.get(p1)
        p0.contentholder?.setOnClickListener {
            if (p1==0) {val mainScreenFragment = MainScreenFragment()
                (mcontent as MainActivity).supportFragmentManager
                    .beginTransaction()
                    .replace(R.id.details_fragment, mainScreenFragment)
                    .commit()
            } else if (p1 == 1) {
                val favoriteFragment = FavoriteFragment()
                (mcontent as MainActivity).supportFragmentManager
                    .beginTransaction()
                    .replace(R.id.details_fragment, favoriteFragment)
                    .commit()
            } else if (p1 == 2) {
                val settingsFragment = SettingsFragment()
                (mcontent as MainActivity).supportFragmentManager
                    .beginTransaction()
                    .replace(R.id.details_fragment, settingsFragment)
                    .commit()
            } else if (p1 == 3) {
                val aboutUsFragment = AboutUsFragment()
                (mcontent as MainActivity).supportFragmentManager
                    .beginTransaction()
                    .replace(R.id.details_fragment, aboutUsFragment)
                    .commit()
            }
            MainActivity.Statified.drawerLayout?.closeDrawers()
        }
    }


    class NavViewHolder(itemView: View):RecyclerView.ViewHolder(itemView)
    {
        var icon_Get:ImageView?=null
        var text_Get:TextView?=null
        var contentholder:RelativeLayout?=null
        init {
            icon_Get= itemView.findViewById(R.id.icon_navdrawer)
            text_Get= itemView.findViewById(R.id.text_navdrawer)
            contentholder= itemView.findViewById(R.id.navdrawer_item_content_holder)
        }

    }
}